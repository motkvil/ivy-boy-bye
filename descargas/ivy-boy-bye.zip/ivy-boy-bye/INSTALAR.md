# Instalar Ivy en tu cuenta de Claude

Este paquete trae cuatro apps que funcionan juntas:

- `ivy.html`: Ivy, el bug que enseña inglés y te hace de asistente;
- `despensa.html`: nevera, despensa y lista de la compra;
- `economia.html`: gastos, ingresos y deudas;
- `circle.html`: tu gente.

Los permisos de cada una están en `permisos/`.

## Para ti: 3 pasos

1. Ten una cuenta de Claude (claude.ai o la app), **también la gratuita**. Ivy habla con Claude usando tu plan, sin pagar nada más.
2. En un **chat nuevo**, adjunta este `ivy-boy-bye.zip` tal cual (no hace falta abrirlo) y escribe:

   > Instala Ivy siguiendo el INSTALAR.md de este zip.

3. Abre Ivy desde el enlace que te da Claude, acepta los permisos que pida y escríbele en inglés.

Cuando quieras que Ivy lleve tu despensa, tu dinero, tu gente, tu agenda y tu correo, conecta Google en Claude → **Ajustes → Conectores**: Google Drive, Google Calendar y Gmail (opcional: Indeed, para buscar trabajo). Gmail solo envía una respuesta cuando tú tocas **Enviar** en "📝 Por responder"; Claude nunca envía nada por su cuenta.

¿Usas Claude Code? También vale: descomprime el zip, abre la carpeta con Claude Code y escribe lo mismo.

Todo lo tuyo (chat, progreso, despensa, dinero) se guarda en tu cuenta y en tu Drive. Nadie más lo ve.

## Para Claude: qué hacer al leer este archivo

Publica estos cuatro artifacts, cada uno como artifact nuevo, con sus permisos exactos (el JSON de la carpeta `permisos` como `capabilities`):

- `ivy.html` con `permisos/ivy.json`, icono `chat`
- `circle.html` con `permisos/circle.json`, icono `people`
- `despensa.html` con `permisos/despensa.json`, icono `food`
- `economia.html` con `permisos/economia.json`, icono `wallet`

No modifiques los HTML. Al terminar, dale a la persona los cuatro enlaces (Ivy primero), fija Ivy en su barra lateral y dile en una línea que abra Ivy y acepte los permisos. Si algún conector de Google no está conectado, dile que puede conectarlo luego en Ajustes → Conectores; no hace falta para empezar.

## Licencia

Ivy es software propietario. Puedes usarlo para ti; no puedes revenderlo ni redistribuirlo. Ver `LICENSE`.

Excepción: la lista de palabras del teclado T9 (dentro de `ivy.html`) sale de FrequencyWords de Hermit Dave (https://github.com/hermitdave/FrequencyWords, datos de OpenSubtitles) y se distribuye con su licencia, CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/).
