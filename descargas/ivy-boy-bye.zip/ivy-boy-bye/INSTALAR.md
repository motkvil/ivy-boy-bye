# Instalar Ivy en tu cuenta de Claude

Este paquete trae cuatro apps que funcionan juntas:

- `ivy.html`: Ivy, la profe de inglés y asistente;
- `despensa.html`: nevera, despensa y lista de la compra;
- `economia.html`: gastos, ingresos y deudas;
- `circle.html`: tu gente.

Los permisos de cada una están en `permisos/`.

## Lo que necesitas

1. Una cuenta de Claude, **también la gratuita**. Ivy habla con Claude usando tu plan, sin pagar nada más; con un plan de pago aguanta más mensajes al día.
2. En claude.ai, ve a **Ajustes → Conectores** y conecta **Google Drive**, **Google Calendar** y **Gmail**.
   - Ivy guarda la despensa, el dinero y tu gente en tu Drive.
   - Gmail lo usa para leer correos, dejarte borradores y proponerte respuestas. Solo envía una respuesta cuando tú tocas **Enviar** en "📝 Por responder"; Claude nunca envía nada por su cuenta.
   - Opcional: **Indeed**, si quieres que Ivy te busque ofertas de trabajo. Sin él, Ivy sigue usando tus alertas de empleo del correo.

## Instalar

1. En claude.ai (o la app de Claude) abre una **conversación nueva**.
2. Adjunta este archivo `ivy-boy-bye.zip` (o los cuatro `.html` y la carpeta `permisos`).
3. Pega este mensaje:

> Publica estos cuatro artifacts, cada uno como artifact nuevo, con sus permisos exactos (el JSON de la carpeta `permisos` como `capabilities`):
> - `ivy.html` con `permisos/ivy.json`, icono `flower`
> - `circle.html` con `permisos/circle.json`, icono `people`
> - `despensa.html` con `permisos/despensa.json`, icono `food`
> - `economia.html` con `permisos/economia.json`, icono `wallet`
>
> No modifiques los HTML. Al terminar, dame los cuatro enlaces y fija Ivy en mi barra lateral.

4. Abre Ivy desde el enlace o la barra lateral y acepta los permisos que pida: Claude, Google Drive, Google Calendar, Gmail, descargas (para bajarte tus CVs en Word) e Indeed (la primera vez que le pidas buscar trabajo).

¿Usas Claude Code? También vale: descomprime el zip, abre la carpeta con Claude Code y pega el mismo mensaje.

Listo. Todo lo tuyo (chat, progreso, despensa, dinero) se guarda en tu cuenta y en tu Drive. Nadie más lo ve.

## Licencia

Ivy es software propietario. Puedes usarlo para ti; no puedes revenderlo ni redistribuirlo. Ver `LICENSE`.
